void	swap_in();
void	swap_out();
