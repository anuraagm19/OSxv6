#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

#define N 20
int
main(int argc, char *argv[])
{
	
	int pagefault=0;
	printf(1, "\nHi I am Parent Process [pid=%d]\n", getpid());
	for(int i = 0; i < 20; i++)
	{
		int f = fork();
		if( f < 0 )
		{
			//printf(1, "Failed to create child\n");
		}
		else if( f == 0 )
		{
			int * d[N];
			for(int j=0;j<N;j++)
			{
				d[j]=malloc(1024*sizeof(int));
				printf(1, "\nmalloc %d\n", d[j]);
				// printf(1,"");
				for(int k=0;k<1024;k++)
					d[j][k]=k;	
				
			}
			for(int j = 0; j < N; j++)
			{
				for(int k=0;k<1024;k++)
					if(d[j][k]!=k)
					{	
						printf(1,"pagefault occured\n");
						pagefault++;
					}
			}
		        exit();
		}
		else
			;
	}
	for(int i = 0; i < 20; i++)
	{
		int f = wait();
		printf(1,"Child Process [pid=%d] exited.\n", f); 
	}
	printf(1,"pagefault=%d\n",pagefault);

	exit();
}
